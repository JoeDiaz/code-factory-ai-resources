﻿namespace CompanyName.AppNameToBeReplaced.Presenters.Api.Rest.Controllers
{
    public class Placeholder
    {
    }
}

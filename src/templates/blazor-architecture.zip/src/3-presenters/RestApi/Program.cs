using CompanyName.AppNameToBeReplaced.Presenters.Api.Rest;
using CompanyName.Delivery.Serilog;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.AspNetCore.Authorization;
using Serilog;

// 1. Initialize Bootstrap Logger (Earliest):
// This logger is used for logging *before* the main host and configuration are fully loaded.
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information() // Set a default minimum level
    .Filter.ByExcluding(c => c.Properties.Any(p => p.Value.ToString().Contains("/health"))) // Exclude health check logs
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .CreateBootstrapLogger();

try
{
    var builder = WebApplication.CreateBuilder(args);

    // 2. Load Local appsettings (Development Only - Before Host Configuration):
    // This allows developers to override settings locally.
    if (builder.Environment.IsDevelopment())
    {
        builder.Configuration.AddJsonFile("appsettings.local.json", optional: true, reloadOnChange: true);
    }

    // 3. Configure Serilog (After Configuration is Available):
    // Now that configuration is loaded (including potentially appsettings.local.json), configure Serilog.
    builder.Host.UseSerilog((context, services, configuration) => configuration
        .ReadFrom.Configuration(context.Configuration)
        .ReadFrom.Services(services)
        .Enrich.FromLogContext()
        .WriteTo.Console());

    // 4. Register Services (Any Order within Services):
    // These services are registered with the dependency injection container.
    builder.Services.AddControllers();
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();
    builder.Services.AddHealthChecks().AddCheck<HealthCheckAsync>("ApplicationHealthCheck");

    // 5. Authentication (Before Authorization):
    // Configure authentication providers.
    builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
        .AddNegotiate();

    // 6. Authorization Policies (Before app.UseAuthorization()):
    // Define authorization policies.  These determine who can access what.
    builder.Services.AddAuthorization(options =>
    {
        // Use default policy when running locally
        if (builder.Environment.IsDevelopment())
        {
            options.FallbackPolicy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .Build();
        }
        else
        {
            // Get the api consumers group name from configuration:
            var apiConsumerGroup = builder.Configuration.GetValue<string>("ApiConsumersGroup");

            // Use consumer group policy when in a prod-like environment
            options.AddPolicy("API_Consumers", policy =>
            {
                policy.RequireRole(apiConsumerGroup);
            });
        }
    });

    // 7. Register Library Dependencies with DI Container:
    var serviceLoader = new LibraryLoader();
    serviceLoader.Load(builder.Services, builder.Configuration);

    var app = builder.Build();

    // 8. Configure Middleware Pipeline (Specific Order):

    // 8a. Swagger (Development Only - Before Routing):
    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }

    // 8b. HTTPS Redirection (If Needed - Before Routing):
    app.UseHttpsRedirection(); // Redirect HTTP to HTTPS

    // 8c. Routing (Essential - Before Authentication/Authorization):
    app.UseRouting(); // Maps incoming requests to endpoints

    // 8d. Authentication (If Needed - Before Authorization):
    // Authentication middleware.  Often implicit with UseAuthorization.
    app.UseAuthentication(); // Might not be needed in .NET 8, but explicit is sometimes better for clarity

    // 8e. Authorization (Crucial - After Authentication and Routing):
    app.UseAuthorization(); // Checks if the user is authorized to access the endpoint

    // 8f. Health Checks (Before Endpoints):
    app.MapHealthChecks("/health").AllowAnonymous(); // Make health check accessible

    // 8g. Configure API Endpoints (Last):
    if (app.Environment.IsDevelopment())
    {
        app.MapControllers(); // No Authorization in development
    }
    else
    {
        // Apply authorization policy to controllers
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers().RequireAuthorization("API_Consumers");
        });
    }

    // 8h. Serilog Request Logging (After Routing/Endpoints):
    app.UseSerilogTraceId(); // Logs request information

    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "The host has crashed.");
    return 1; // Non-zero exit code indicates failure
}
finally
{
    Log.CloseAndFlush(); // Flush logs before exiting
}

return 0; // Zero exit code indicates success
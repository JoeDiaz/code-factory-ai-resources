﻿using System;

namespace CompanyName.AppName.Clients.RestApi
{
    public class Class1
    {

    }
}

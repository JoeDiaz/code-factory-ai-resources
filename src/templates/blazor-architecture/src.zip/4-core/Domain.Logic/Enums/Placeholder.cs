﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CompanyName.AppNameToBeReplaced.Core.Domain.Logic.Enums
{
    internal class Placeholder
    {
    }
}

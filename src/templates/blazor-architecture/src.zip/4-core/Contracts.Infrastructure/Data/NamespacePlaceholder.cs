﻿namespace CompanyName.AppNameToBeReplaced.Core.Contracts.Infrastructure.Data
{

}
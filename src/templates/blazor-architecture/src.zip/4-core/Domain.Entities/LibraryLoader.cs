﻿using CodeFactory.NDF;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace CompanyName.AppNameToBeReplaced.Core.Domain.Entities
{
    public class LibraryLoader : DependencyInjectionLoader
    {
        protected override void LoadLibraries(IServiceCollection serviceCollection, IConfiguration configuration)
        {
            // Intentionally Blank
        }

        protected override void LoadManualRegistration(IServiceCollection serviceCollection, IConfiguration configuration)
        {
            // Intentionally Blank
        }



        /// <summary>
        /// Automated registration of classes using transient registration.
        /// </summary>
        /// <param name="serviceCollection">The service collection to register services.</param>
        /// <param name="configuration">The configuration data used with register of services.</param>
        protected override void LoadRegistration(IServiceCollection serviceCollection, IConfiguration configuration)
        {
            //This method was auto generated, do not modify by hand!
        }
    }
}
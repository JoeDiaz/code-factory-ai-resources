﻿using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace CompanyName.AppNameToBeReplaced.Presenters.Api.Rest
{
    public class HealthCheckAsync : IHealthCheck
    {
        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            try
            {
                return Task.FromResult(HealthCheckResult.Healthy("Successful Health Check"));
            }
            catch (Exception)
            {
                return Task.FromResult(new HealthCheckResult(context.Registration.FailureStatus, "Unsuccessful Health Check."));
            }
        }
    }

}
﻿using CodeFactory.NDF;

namespace CompanyName.AppNameToBeReplaced.Presenters.Api.Rest
{
    public class LibraryLoader : DependencyInjectionLoader
    {
        protected override void LoadLibraries(IServiceCollection serviceCollection, IConfiguration configuration)
        { 
            var domainEntitiesLoader = new CompanyName.AppNameToBeReplaced.Core.Domain.Entities.LibraryLoader();
            var logicLoader = new CompanyName.AppNameToBeReplaced.Core.Domain.Logic.LibraryLoader();
            var dataSqlLoader = new CompanyName.AppNameToBeReplaced.Infrastructure.Data.Sql.LibraryLoader();

            domainEntitiesLoader.Load(serviceCollection, configuration);
            logicLoader.Load(serviceCollection, configuration);
            dataSqlLoader.Load(serviceCollection, configuration);
        }

        protected override void LoadManualRegistration(IServiceCollection serviceCollection, IConfiguration configuration)
        {
            // Intentionally Blank
        }

        /// <summary>
        /// Automated registration of classes using transient registration.
        /// </summary>
        /// <param name="serviceCollection">The service collection to register services.</param>
        /// <param name="configuration">The configuration data used with register of services.</param>
        protected override void LoadRegistration(IServiceCollection serviceCollection, IConfiguration configuration)
        {
            //This method was auto generated, do not modify by hand!
        }
    }
}

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Tests.Sql.IntegrationTests
{
	/// <summary>
	/// Loader class that is used by testing to load required services.
	/// </summary>
	public static class TestLoader
	{
		/// <summary>
		/// Backing field for the <see cref="Configuration"/> property.
		/// </summary>
		private static readonly IConfiguration _configuration;
		
		/// <summary>
		/// Backing field for the <see cref="ServiceProvider"/> property.
		/// </summary>
		private static readonly IServiceProvider _serviceProvider;
		
		/// <summary>
		/// Logging factory used for testing
		/// </summary>
		private static readonly ILoggerFactory _loggerFactory;
		
		/// <summary>
		/// Constructor that gets called when the class is accessed for the first time.
		/// </summary>
		static TestLoader()
		{
			//Loading the configuration
			var configuration = new ConfigurationBuilder()
			    .AddJsonFile("appsettings.local.json", true)
			    .AddEnvironmentVariables().Build();
			
			//Setting the config property.
			_configuration = configuration;
			
			//Creating the service container
			var services = new ServiceCollection();
			
			//Adding access to configuration from the service container
			services.AddSingleton<IConfiguration>(Configuration);
			
			//Loading the libraries into the service collection.
			LoadLibraries(services, _configuration);
			
			_loggerFactory = new NullLoggerFactory();
			
			services.AddSingleton(_loggerFactory);
			
			services.AddLogging();
			//Building the service provider.
			_serviceProvider = services.BuildServiceProvider();
			
		}
		
		/// <summary>
		/// The loaded configuration to be used with testing.
		/// </summary>
		public static IConfiguration Configuration => _configuration;
		
		/// <summary>
		/// Service provider for the loaded dependency configuration.
		/// </summary>
		public static IServiceProvider ServiceProvider => _serviceProvider;
		
		/// <summary>
		/// Gets the required service to use with testing.
		/// </summary>
		/// <typeparam name="T">Type of the service to be loaded.</typeparam>
		/// <returns>Instance of the service</returns>
		public static T GetRequiredService<T>() where T : notnull
		{
			return _serviceProvider.GetRequiredService<T>();
		}
		
		/// <summary>
		/// Loads the libraries into service collection
		/// </summary>
		/// <param name="services">Service collection to load.</param>
		/// <param name="configuration">The configuration to be provided to services.</param>
		public static void LoadLibraries(IServiceCollection services, IConfiguration configuration)
		{
            var sqlRepoLoader = new CompanyName.AppNameToBeReplaced.Infrastructure.Data.Sql.LibraryLoader();
            sqlRepoLoader.Load(services, configuration);
        }
	}
}
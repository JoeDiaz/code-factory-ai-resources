﻿using CompanyName.Delivery.Data.Sql;
using CompanyName.AppNameToBeReplaced.Core.Contracts.Infrastructure.Data;  
using CompanyName.AppNameToBeReplaced.Infrastructure.Data.Sql.Entities;
using CompanyName.AppNameToBeReplaced.Infrastructure.Data.Sql.Repositories;
using CodeFactory.NDF;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CompanyName.AppNameToBeReplaced.Infrastructure.Data.Sql
{
    public class LibraryLoader : DependencyInjectionLoader
    {
        protected override void LoadLibraries(IServiceCollection serviceCollection, IConfiguration configuration)
        {
            serviceCollection.AddDapperSqlConnectionFactory();
        }

        protected override void LoadManualRegistration(IServiceCollection serviceCollection, IConfiguration configuration)
        {
            // Used for Dapper
            /*
            serviceCollection.AddSingleton<IDBContextConnection<AppNameToBeReplacedContext>>
            (
                sp => new DBContextConnection<AppNameToBeReplacedContext>(configuration.GetConnectionString("AppNameToBeReplacedDbConnectionString"))
            );
            */

            // Used for EF
            /*
            serviceCollection.AddDbContextFactory<AppNameToBeReplacedContext>
            (
                options => options.UseSqlServer(configuration.GetConnectionString("AppNameToBeReplacedDbConnectionString"))
            );
            */
        }



        /// <summary>
        /// Automated registration of classes using transient registration.
        /// </summary>
        /// <param name="serviceCollection">The service collection to register services.</param>
        /// <param name="configuration">The configuration data used with register of services.</param>
        protected override void LoadRegistration(IServiceCollection serviceCollection, IConfiguration configuration)
        {
            //This method was auto generated, do not modify by hand!
            
        }
    }
}